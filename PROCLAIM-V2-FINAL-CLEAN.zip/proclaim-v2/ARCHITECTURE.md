# PROCLAIM V2 Architecture

Browser -> Express API -> services -> SQLite / MediaService

## Frontend
`public/index.html` provides the shell, SVG icon sprite and responsive navigation. `public/app.js` handles routing-like page rendering, API calls, forms, uploads and interactions. `public/styles.css` contains the shared Matte Black / Neon Sky Blue design system.

## Backend
`src/server.js` provides authentication, profile APIs, posts, reactions, saves, comments, follows, Explore, messaging, groups, channels, store, inventory, wallet, reports and Owner APIs.

## Database
SQLite keeps the free deployment portable. Foreign keys, WAL and indexes are enabled. Schema evolution is handled by the migration file and compatibility checks in `src/db.js`.

## Media
Media bytes live outside normal database rows. Database rows contain ownership, MIME type, size, original name and file key. `MediaService` is the abstraction point for a later S3/R2/object-storage adapter.

## Authorization
The backend determines identity from the HttpOnly session. Owner APIs require both an active session and `kind='owner'` plus `role='OWNER'`. Frontend state is never treated as authorization.

## Realtime
Socket.IO is installed and users join `user:<id>` rooms. Direct-message events can be emitted to recipient rooms. The persistent source of truth remains SQLite.
