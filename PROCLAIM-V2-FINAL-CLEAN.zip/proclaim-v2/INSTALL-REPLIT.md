# Replit quick start

1. Upload/extract this folder into a new Replit Node.js project.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Set `JWT_SECRET` to a long random string.
5. Set `OWNER_USERNAME` and `OWNER_PASSWORD` to your own strong credentials.
6. Run `npm start`.
7. Use the Replit webview URL.
8. Owner login: `/owner-login`.

No paid hosting, paid database, or card is required for this development setup. SQLite and local media storage are included for the zero-cost development environment.
