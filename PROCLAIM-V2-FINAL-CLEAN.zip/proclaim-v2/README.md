# PROCLAIM V2

PROCLAIM V2 is a portable social + messenger + media + digital-store platform.

## What is implemented

- Responsive Persian RTL interface with English-ready structure
- Matte black + Neon Sky Blue visual system
- Neon-blue microphone logo supplied for the project
- SVG-only interface icon system (no Unicode emoji navigation)
- Username + password registration; email is optional
- Secure password hashing, HttpOnly session cookie, login-attempt logging and server-side authorization
- Separate Owner login/session kind and Owner-only APIs
- Home feed with public/followers/private visibility
- Desktop composer and mobile central `+` SVG composer
- Real image upload to persistent local storage with media metadata in SQLite
- Real posts, image attachments, likes, comments, saves and follows
- Explore templates for For You, trends, people, public channels and public groups
- Direct messages between users, persisted in SQLite, with Socket.IO room infrastructure
- Saved Messages private notes
- Groups with public/private visibility, unique public handles and a 10-public-group-per-user limit
- Channels with public/private visibility, unique public handles and a 10-public-channel-per-user limit
- Group/channel avatar and cover upload endpoints
- Digital Store, categories, limited supply, purchases and inventory/collection
- PRO Coin internal wallet and immutable transaction rows for balance changes
- Premium and Creator Studio foundations
- Reports and Owner moderation controls
- Owner dashboard with platform statistics
- Owner management for users, posts, groups, channels, store items, reports, audit logs, settings and feature flags
- Store preview upload from Owner Panel
- Database migrations plus compatibility additions for earlier V2 databases
- Demo data is clearly labelled and can be removed by normal Owner moderation actions

## Run

```bash
npm install
cp .env.example .env
npm start
```

Open the port exposed by your environment. On Replit, use the generated webview URL.

## Owner

Set `OWNER_USERNAME`, `OWNER_PASSWORD` and `JWT_SECRET` in `.env`. The normal application never trusts a role sent by the browser. Owner access requires an Owner session created by `/api/owner/login` and is not granted by merely visiting an admin URL.

## Storage

Development uses `DATA_DIR/uploads`. The `MediaService` abstraction keeps storage logic separate so an object-storage adapter can be introduced later without changing post/profile/store APIs.

## Payments

PRO Coin is internal. Store purchases in this build spend server-authoritative PRO Coin. No external withdrawal is implemented. A production payment provider should verify payments server-side before crediting coins.

## Database

SQLite is used for a free, portable development deployment. WAL mode and foreign keys are enabled. The schema is in `migrations/001_initial.sql`; `src/db.js` also adds forward-compatible columns/indexes when an earlier V2 database is opened.

## Demo data

The seed creates one clearly labelled demo user/post and a couple of clearly labelled sample store items only when they do not already exist. They are ordinary database records and can be removed through Owner controls.

## Important production note

This is a substantial working V2 foundation, not a claim that every future social-network feature (for example full WebRTC calling, production object storage, a real payment provider, advanced recommendation ML, or complete creator payouts) is magically available without external infrastructure. Those integrations are intentionally separated from the core application.


## Social expansion included in this build
This build adds working server-backed Stories (24h), public profile viewing, repost/quote-post, message edit/delete, presence tracking, notifications, block/mute, hashtag pages, group/channel detail views, post pinning, Owner verification controls, real gift sending, collection cosmetic application, Owner media manager, user inspector, trash/restore for owner-deleted posts, advanced search API, feed cursor pagination with infinite-scroll UI, and internal post sharing to direct messages. Draft posts and pre-publication preview workflows are intentionally not included.

These features use SQLite transactions and server-side authorization; UI controls are backed by API routes and persistent database records rather than static demo-only buttons.


### Owner security
Owner login is isolated from normal user login. The Owner account requires password + mandatory TOTP 2FA, and a new Owner login revokes previous active Owner sessions. Owner sessions persist for up to 30 days unless revoked.

For a new deployment, run `npm run setup-owner-2fa`, add the printed TOTP secret/otpauth URI to your authenticator, then restart the server. Keep `.env` private.

## Clean GitHub/Codespaces deployment

Extract this archive into a new empty repository/folder. Do not overlay it on an older PROCLAIM V2 extraction. Then run:

```bash
npm install
cp .env.example .env
npm run create-owner -- owner 'YOUR_STRONG_PASSWORD'
npm run setup-owner-2fa
npm start
```

The server listens on `0.0.0.0` and uses `PORT` when supplied by the host (default `3000`). Codespaces/hosted environments can therefore expose the same process through their forwarded port.
