# Security notes

- Passwords are hashed with bcrypt.
- Sessions are random server-side identifiers stored in SQLite and sent through HttpOnly cookies.
- Owner sessions use a distinct `kind=owner` value.
- If `OWNER_TOTP_SECRET` is configured, Owner login requires a valid TOTP code.
- Role checks happen on the server.
- Authentication endpoints are rate-limited.
- Uploads are limited by size and accepted MIME type.
- User-supplied text is HTML-escaped by the frontend renderer.
- SQL values use prepared statements.
- Wallet balances are server-authoritative and every balance mutation creates a transaction row.
- Payment credentials such as card numbers/CVV are not stored by this application.
- Audit logs record Owner-sensitive operations.

Before production, add a real object-storage provider, HTTPS, a production payment provider with verified webhooks, CSRF strategy appropriate to deployment, stronger account recovery, optional Owner 2FA enforcement, backups and operational monitoring.
