CREATE TABLE IF NOT EXISTS channel_posts (channel_id INTEGER NOT NULL, post_id INTEGER NOT NULL UNIQUE, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(channel_id,post_id), FOREIGN KEY(channel_id) REFERENCES channels(id) ON DELETE CASCADE, FOREIGN KEY(post_id) REFERENCES posts(id) ON DELETE CASCADE);
CREATE INDEX IF NOT EXISTS idx_channel_posts_channel ON channel_posts(channel_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_channel_members_role ON channel_members(channel_id,role);
