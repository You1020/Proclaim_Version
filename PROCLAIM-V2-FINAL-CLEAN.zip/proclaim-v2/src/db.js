import Database from 'better-sqlite3';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const dataDir=path.resolve(process.env.DATA_DIR||path.join(root,'data'));
fs.mkdirSync(dataDir,{recursive:true});
export const db=new Database(path.join(dataDir,'proclaim.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('busy_timeout = 5000');

const migration=fs.readFileSync(path.join(root,'migrations/001_initial.sql'),'utf8');
db.exec(migration);
for (const file of ['migrations/002_social_expansion.sql','migrations/003_community_spaces.sql']) { db.exec(fs.readFileSync(path.join(root,file),'utf8')); }

// Forward-compatible additions for databases created by an earlier V2 build.
const additions={
  users:[
    ['cover_media_id','INTEGER'],
    ['updated_at','TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP']
  ],
  profiles:[
    ['background_media_id','INTEGER'],['effect_id','INTEGER'],['cover_id','INTEGER'],
    ['avatar_frame_id','INTEGER'],
    ['name_style','TEXT DEFAULT \'default\'']
  ],
  groups_:[
    ['handle','TEXT'],['visibility','TEXT NOT NULL DEFAULT \'PUBLIC\''],['status','TEXT NOT NULL DEFAULT \'ACTIVE\''],['cover_media_id','INTEGER']
  ],
  channels:[
    ['visibility','TEXT NOT NULL DEFAULT \'PUBLIC\''],['status','TEXT NOT NULL DEFAULT \'ACTIVE\''],['cover_media_id','INTEGER']
  ],
  posts:[['media_alt','TEXT DEFAULT \'\'']]
};
for(const [table,cols] of Object.entries(additions)){
  const existing=new Set(db.prepare(`PRAGMA table_info(${table})`).all().map(x=>x.name));
  for(const [name,type] of cols) if(!existing.has(name)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${name} ${type}`);
}


const msgCols=new Set(db.prepare('PRAGMA table_info(messages)').all().map(x=>x.name));
if(!msgCols.has('post_id')) db.exec('ALTER TABLE messages ADD COLUMN post_id INTEGER');

db.exec(`
CREATE INDEX IF NOT EXISTS idx_saved_messages_user ON saved_messages(user_id,created_at);
CREATE UNIQUE INDEX IF NOT EXISTS idx_public_group_handle ON groups_(handle) WHERE handle IS NOT NULL AND handle <> '';
CREATE INDEX IF NOT EXISTS idx_groups_owner ON groups_(owner_id);
CREATE INDEX IF NOT EXISTS idx_channels_owner ON channels(owner_id);
CREATE INDEX IF NOT EXISTS idx_messages_recipient ON messages(recipient_user_id,created_at);
CREATE INDEX IF NOT EXISTS idx_saved_user ON saved_posts(user_id,created_at);
`);
