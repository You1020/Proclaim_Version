import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import { db } from './db.js';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const dataRoot=path.resolve(process.env.DATA_DIR||path.join(root,'data'));
const uploadDir=path.join(dataRoot,'uploads');
fs.mkdirSync(uploadDir,{recursive:true});

export const roleRank={USER:1,MODERATOR:2,EDITOR:3,ADMIN:4,OWNER:5};
export const validators={
 register:z.object({username:z.string().min(3).max(32).regex(/^[A-Za-z0-9_]+$/),password:z.string().min(8).max(128),email:z.string().email().max(200).optional().or(z.literal(''))}),
 login:z.object({username:z.string().min(3).max(32),password:z.string().min(1).max(128)}),
 post:z.object({body:z.string().max(5000).default(''),visibility:z.enum(['PUBLIC','FOLLOWERS','PRIVATE']).default('PUBLIC'),mediaIds:z.array(z.number().int().positive()).max(8).default([])}),
 message:z.object({recipientUserId:z.number().int().positive().optional(),groupId:z.number().int().positive().optional(),body:z.string().max(5000).default(''),mediaId:z.number().int().positive().optional(),postId:z.number().int().positive().optional()}).refine(x=>Boolean(x.recipientUserId)!==Boolean(x.groupId),{message:'exactly one message destination is required'}),
 profile:z.object({displayName:z.string().max(80).optional(),bio:z.string().max(500).optional(),avatarMediaId:z.number().int().positive().nullable().optional(),coverMediaId:z.number().int().positive().nullable().optional()}),
};
export const hashPassword=p=>bcrypt.hashSync(p,12);
export const verifyPassword=(p,h)=>bcrypt.compareSync(p,h);
export function newSession(user,kind,req){const id=crypto.randomBytes(32).toString('hex');const exp=new Date(Date.now()+1000*60*60*24*(kind==='owner'?30:7)).toISOString();db.prepare('INSERT INTO sessions(id,user_id,kind,expires_at,ip,user_agent) VALUES(?,?,?,?,?,?)').run(id,user.id,kind,exp,req.ip,req.get('user-agent')||'');return {id,expiresAt:exp};}
export function getSession(id){if(!id)return null;return db.prepare('SELECT s.*,u.username,u.role,u.status FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.id=? AND s.revoked_at IS NULL AND s.expires_at>CURRENT_TIMESTAMP').get(id)||null;}
export function revokeSession(id){if(id)db.prepare('UPDATE sessions SET revoked_at=CURRENT_TIMESTAMP WHERE id=?').run(id);}
export function audit(actor,action,targetType,targetId,prev,next,req){db.prepare('INSERT INTO audit_logs(actor_user_id,action,target_type,target_id,previous_json,new_json,ip,user_agent) VALUES(?,?,?,?,?,?,?,?)').run(actor?.id||null,action,targetType,targetId,prev?JSON.stringify(prev):null,next?JSON.stringify(next):null,req?.ip||null,req?.get('user-agent')||null);}
export const MediaService={
 save({userId,buffer,mimeType,originalName,kind,width,height}){const ext=(originalName?.split('.').pop()||'bin').replace(/[^a-z0-9]/gi,'').slice(0,8)||'bin';const key=`${Date.now()}-${crypto.randomBytes(10).toString('hex')}.${ext}`;fs.writeFileSync(path.join(uploadDir,key),buffer,{flag:'wx'});const r=db.prepare('INSERT INTO media(user_id,file_key,mime_type,size_bytes,width,height,kind,original_name) VALUES(?,?,?,?,?,?,?,?)').run(userId,key,mimeType,buffer.length,width||null,height||null,kind||'generic',String(originalName||'').slice(0,255));return db.prepare('SELECT * FROM media WHERE id=?').get(r.lastInsertRowid)},
 path:m=>path.join(uploadDir,m.file_key)
};
export function wallet(userId){let w=db.prepare('SELECT * FROM wallets WHERE user_id=?').get(userId);if(!w){db.prepare('INSERT INTO wallets(user_id,balance) VALUES(?,0)').run(userId);w=db.prepare('SELECT * FROM wallets WHERE user_id=?').get(userId)}return w;}
export function coin(userId,amount,type,refType=null,refId=null,note=''){const tx=db.transaction(()=>{const w=wallet(userId);const next=w.balance+amount;if(next<0)throw Object.assign(new Error('INSUFFICIENT_FUNDS'),{status:400});db.prepare('UPDATE wallets SET balance=?,updated_at=CURRENT_TIMESTAMP WHERE user_id=?').run(next,userId);const r=db.prepare('INSERT INTO coin_transactions(user_id,amount,type,reference_type,reference_id,note,balance_after) VALUES(?,?,?,?,?,?,?)').run(userId,amount,type,refType,refId,note,next);return {balance:next,transactionId:r.lastInsertRowid}});return tx();}
export const ensureUserWallet=userId=>wallet(userId);
export function seed(){
 const ownerName=String(process.env.OWNER_USERNAME||'').trim();const ownerPass=String(process.env.OWNER_PASSWORD||'');let owner=ownerName?db.prepare('SELECT * FROM users WHERE username=?').get(ownerName):null;
 if(!owner && ownerName && ownerPass && ownerPass!=='replace-with-a-strong-owner-password'){const r=db.prepare('INSERT INTO users(username,password_hash,role) VALUES(?,?,\'OWNER\')').run(ownerName,hashPassword(ownerPass));owner=db.prepare('SELECT * FROM users WHERE id=?').get(r.lastInsertRowid);db.prepare('INSERT INTO profiles(user_id,display_name,bio) VALUES(?,?,?)').run(owner.id,'PROCLAIM Owner','مدیریت رسمی پلتفرم');}
 if(owner) ensureUserWallet(owner.id);
 const settings={siteName:'PROCLAIM',coinPriceUsd:0.01,registrationOpen:true,maxUploadMb:Number(process.env.MAX_UPLOAD_MB||15),maxPublicGroups:10,maxPublicChannels:10};
 for(const [k,v] of Object.entries(settings))db.prepare('INSERT OR IGNORE INTO app_settings(key,value_json) VALUES(?,?)').run(k,JSON.stringify(v));
 for(const key of ['stories','groups','channels','marketplace','gifts','premium','proCoin','exploreTrending','comments','mediaUploads'])db.prepare('INSERT OR IGNORE INTO feature_flags(key,enabled) VALUES(?,1)').run(key);
 const cats=[['Featured','featured'],['New','new'],['Trending','trending'],['Gifts','gifts'],['Themes','themes'],['Covers','covers'],['Frames','frames'],['Fonts','fonts'],['Profile Effects','profile-effects'],['Badges','badges'],['Stickers','stickers'],['Reaction Packs','reaction-packs'],['Premium','premium'],['Creator Marketplace','creator-marketplace'],['Collections','collections']];const ins=db.prepare('INSERT OR IGNORE INTO store_categories(name,slug,sort_order) VALUES(?,?,?)');cats.forEach((x,i)=>ins.run(x[0],x[1],i));
 // Demo content is deliberately minimal and clearly labelled; Owner can delete it.
 if(!db.prepare('SELECT id FROM users WHERE username=\'demo\'').get()){const r=db.prepare('INSERT INTO users(username,password_hash,role) VALUES(?,?,\'USER\')').run('demo',hashPassword('DemoPassword123!'));db.prepare('INSERT INTO profiles(user_id,display_name,bio) VALUES(?,?,?)').run(r.lastInsertRowid,'Demo User','نمونه آزمایشی — از Owner Panel قابل حذف است.');ensureUserWallet(r.lastInsertRowid);db.prepare('INSERT INTO posts(user_id,body,visibility,status) VALUES(?,?,\'PUBLIC\',\'PUBLISHED\')').run(r.lastInsertRowid,'این فقط محتوای نمونه برای تست است و می‌توانید آن را حذف یا با محتوای واقعی جایگزین کنید.');}
 const n=db.prepare('SELECT COUNT(*) n FROM store_items').get().n;if(!n){const f=db.prepare("SELECT id FROM store_categories WHERE slug='frames'").get();const t=db.prepare("SELECT id FROM store_categories WHERE slug='themes'").get();if(f)db.prepare('INSERT INTO store_items(category_id,name,slug,description,price,supply,status,featured) VALUES(?,?,?,?,?,?,?,?)').run(f.id,'Neon Frame 01','neon-frame-01','نمونه قابل حذف.',250,10000,'PUBLISHED',1);if(t)db.prepare('INSERT INTO store_items(category_id,name,slug,description,price,status,featured) VALUES(?,?,?,?,?,?,?)').run(t.id,'Midnight Theme','midnight-theme','نمونه قابل حذف.',120,'PUBLISHED',1);}
}
