import 'dotenv/config';
import fs from 'node:fs';
import crypto from 'node:crypto';
const alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
let secret='';
const bytes=crypto.randomBytes(20);
for(let i=0,bits=0,val=0;i<bytes.length;i++){val=(val<<8)|bytes[i];bits+=8;while(bits>=5){secret+=alphabet[(val>>>(bits-5))&31];bits-=5;}}
if(bits)secret+=alphabet[(val<<(5-bits))&31];
const envPath=new URL('../.env', import.meta.url).pathname;
let env=fs.existsSync(envPath)?fs.readFileSync(envPath,'utf8'):'';
if(/^OWNER_TOTP_SECRET=.*$/m.test(env)) env=env.replace(/^OWNER_TOTP_SECRET=.*$/m,`OWNER_TOTP_SECRET=${secret}`);
else env += `${env.endsWith('\n')?'':'\n'}OWNER_TOTP_SECRET=${secret}\n`;
fs.writeFileSync(envPath,env);
const issuer='PROCLAIM'; const account=process.env.OWNER_USERNAME||'owner';
console.log('Owner 2FA secret saved to .env');
console.log('Secret:',secret);
console.log('Add this TOTP account to an authenticator app:');
console.log(`otpauth://totp/${encodeURIComponent(issuer)}:${encodeURIComponent(account)}?secret=${secret}&issuer=${encodeURIComponent(issuer)}&digits=6&period=30`);
