import test from 'node:test';
import assert from 'node:assert/strict';
import { validators, roleRank } from '../src/services.js';

test('email is optional during registration',()=>{
  const result=validators.register.safeParse({username:'abc_user',password:'Password123!',email:''});
  assert.equal(result.success,true);
});

test('role hierarchy is ordered through OWNER',()=>{
  assert.equal(roleRank.USER<roleRank.MODERATOR,true);
  assert.equal(roleRank.MODERATOR<roleRank.EDITOR,true);
  assert.equal(roleRank.EDITOR<roleRank.ADMIN,true);
  assert.equal(roleRank.ADMIN<roleRank.OWNER,true);
});

test('public post visibility is accepted',()=>{
  const result=validators.post.safeParse({body:'hello',visibility:'PUBLIC',mediaIds:[]});
  assert.equal(result.success,true);
});
