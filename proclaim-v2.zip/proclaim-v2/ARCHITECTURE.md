# Architecture

Browser UI -> Express API -> domain services -> SQLite
                         |-> MediaService -> local disk (development)
                         |-> Socket.IO -> realtime message delivery

The frontend never owns authorization, price, wallet balance, role, or payment success.

### Major modules
- Auth/session: `src/services.js`, `/api/auth/*`
- Owner: `/api/owner/*`
- Social: posts, reactions, comments, follows
- Messaging: messages API + Socket.IO rooms
- Media: `MediaService` provider abstraction
- Store: categories, items, inventory
- Economy: wallets + immutable-ish transaction history
- Moderation: reports + audit logs
- Configuration: app settings + feature flags
- V1: `public/legacy-v1.html`

### Extending storage
Implement a second provider with the same `save()` and `path()` contract and select it through `STORAGE_PROVIDER`. For a production object store, return a public/signed URL from the provider rather than serving local files.
