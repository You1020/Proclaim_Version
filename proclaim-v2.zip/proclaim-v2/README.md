# PROCLAIM V2

A portable, dark/neon-blue social platform foundation built around the supplied Proclaim V1 file. V1 is preserved as `public/legacy-v1.html`; V2 adds a real Express backend, SQLite database, authentication, owner authorization, media uploads, social actions, groups/channels, messages, store/inventory, PRO Coin ledger, gifts, reports, audit logs, feature flags, and a responsive UI.

## Run

```bash
npm install
cp .env.example .env
# edit .env and set a strong OWNER_PASSWORD + JWT_SECRET
npm start
```

Open `http://localhost:3000`.

## Owner

Owner is seeded from environment variables on startup. Owner authorization is checked on the server, never trusted from the browser. Owner login is at `/owner-login`. The owner session uses a signed HTTP-only cookie and has a separate `owner` guard. TOTP 2FA endpoints are included; set `OWNER_2FA_REQUIRED=true` after configuring a secret through the owner security API/UI.

## Database

SQLite is used for zero-cost local/Replit development. Schema is migration-based in `migrations/001_initial.sql`. The backend automatically applies migrations. For production, the repository is structured so SQLite can be replaced with a managed SQL adapter without changing the domain services.

## Media

`MediaService` stores metadata in SQLite and binary files through a provider interface. Development uses local disk (`data/uploads`). The interface is intentionally isolated so S3/R2/another object-storage provider can be added without rewriting routes.

## Payments / PRO Coin

The included payment provider is explicitly a development mock. It verifies nothing externally and must not be presented as real money. PRO Coin is internal-only, non-withdrawable, and every wallet change is ledgered. Production payments require a legitimate provider and server-side webhook verification.

## Demo data

On first startup, a small demo dataset is inserted so the UI is not empty. Owner can delete demo records from the owner panel. Demo payment records are never created.

## V1 preservation

The exact supplied V1 HTML is copied unchanged to `public/legacy-v1.html`. V2 does not delete it.

## Production notes

Use HTTPS, a strong secret, secure cookies, a production database, object storage, a real payment provider, backups, monitoring, and a reverse proxy. Do not commit `.env` or owner credentials.
