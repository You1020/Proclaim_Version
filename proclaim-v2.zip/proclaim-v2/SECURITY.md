# PROCLAIM V2 security model

- Passwords are hashed with bcrypt.
- Authentication sessions are stored server-side and represented to the browser by an HttpOnly SameSite cookie.
- Owner routes use a server-side OWNER role guard; frontend visibility is not authorization.
- Login attempts are logged and auth endpoints are rate limited.
- Helmet and CORS are configured.
- Media uploads accept only image MIME types and have a server-side byte limit.
- PRO Coin changes are made through the backend ledger and reject negative balances.
- Destructive Owner operations create audit records.
- Raw card/CVV data is never accepted or stored by this project.
- The default payment provider is explicitly a development mock.

For public production deployment, use HTTPS, rotate secrets, put the database/object storage behind proper access controls, add backups, monitoring, CSRF protection appropriate to your deployment topology, stronger abuse controls, and a real verified payment webhook provider.
