import './db.js'; import {hashPassword} from './services.js'; import {db} from './db.js';
const username=process.argv[2]||process.env.OWNER_USERNAME||'owner'; const password=process.argv[3]||process.env.OWNER_PASSWORD;
if(!password){console.error('Provide password as arg 2 or OWNER_PASSWORD');process.exit(1)}
const old=db.prepare('SELECT id FROM users WHERE username=?').get(username); if(old) db.prepare('UPDATE users SET password_hash=?,role="OWNER" WHERE id=?').run(hashPassword(password),old.id); else db.prepare('INSERT INTO users(username,password_hash,role) VALUES(?,?,"OWNER")').run(username,hashPassword(password));
console.log(`Owner ready: ${username}`);
